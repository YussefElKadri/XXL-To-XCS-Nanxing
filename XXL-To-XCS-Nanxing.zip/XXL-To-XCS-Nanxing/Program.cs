﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace XXL_To_XCS_Nanxing
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Thread.Sleep(1000);
		}
	}
}
